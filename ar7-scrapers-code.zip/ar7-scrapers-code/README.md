# AR7 Traders — Car & Machinery Scrapers

Standalone archive preserving exact repository paths so all ES module relative
imports resolve cleanly out of the box (Node 20+).

## Contents

### 1. Car Scraper (Japan Dealer Stock / Goo-net Exchange)
- `api/goonet-sync.js` — Serverless daily importer & self-healing cron (`?key=...`, also runs `?job=machinery*`)
- `api/goonet-stock.js` — Staff API for browsing, promoting, and hiding imported Japan stock
- `scripts/goonet-core.mjs` — Fetcher, Jina/relay support, Shift-JIS / UTF-8 decoder, card & detail HTML parsers, quality gate, optional LLM fallback
- `scripts/goonet-crawl.mjs` — CLI crawler / dry-run runner (`node scripts/goonet-crawl.mjs`)
- `scripts/goonet-diag.mjs`, `scripts/goonet-repair.mjs`, `scripts/goonet-seed.mjs`, `scripts/clean-goonet.js`
- `scripts/sync-core.mjs`, `scripts/sync-site-listings.mjs`, `scripts/check-sync-report.mjs`, `scripts/legacy-jp.mjs`
- `src/japan-stock-map.js`, `src/jp-display.js`
- `.github/workflows/goonet-sync.yml` & `GOONET-SYNC.md`

### 2. Machinery Scraper (China / Made-in-China & Supplier Packages)
- `api/_machinery-scraper.js` — Made-in-China category & product scraper (robots.txt polite crawl, price/spec parsing, preview pipeline)
- `api/_machinery-import.js` — Preview -> classify -> rights check -> markup -> upsert (`step=preview|confirm|scraper|stale`)
- `api/_machinery.js` — Machinery storage validation, rights gates, publish recovery, doctor diagnostics
- `src/machinery-source.js`, `src/machinery-data.js`, `src/sitemap-helpers.js`
- `scripts/machinery-sync.mjs` — Automated batch photo & source verification runner
- `scripts/import-machinery.mjs` — Local supplier package importer & photo watermark check
- `scripts/brand-machine-photo.sh` — Branded backdrop helper
- `.github/workflows/machinery-sync.yml`, `MACHINERY-SOURCES.md`, `MACHINERY-RECOVERY.md`

### 3. Shared Server Helpers & SQL Schemas
- `api/_supabase.js`, `api/_perm.js`, `api/_columns.js`, `api/_gemini.js`, `api/_gemini-errors.js`, `api/_activity.js`
- `supabase/MIGRATION-2026-10-machinery.sql`, `supabase/machinery.sql`, `supabase/japan-stock-seed.sql`

## Quick Start

1. Install the Supabase SDK (only runtime npm dependency used by the scrapers):
   ```bash
   npm init -y && npm pkg set type=module && npm install @supabase/supabase-js
   ```
2. Provide required environment variables (never commit secrets):
   - `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
   - `GOONET_SYNC_KEY` (scheduled endpoint auth)
   - Optional relay / AI helpers: `JINA_API_KEY`, `GOONET_RELAY_URL`, `GEMINI_API_KEY`
3. Run diagnostics or dry-run crawl:
   ```bash
   node scripts/goonet-diag.mjs
   node scripts/goonet-crawl.mjs --dry
   ```
